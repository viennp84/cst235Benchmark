package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.xml.bind.annotation.XmlRootElement;

/*
 * CST235-Benchmark
 * Vien Nguyen
 * This is the bible class,
 * The class has the attributes of the bible.
 * */
@ManagedBean
@ViewScoped
@XmlRootElement(name = "bible")
public class Bible {

	int id;
	String testament;
	String book;
	String chapter;
	String verse;
	String vtext;

	public Bible() {
		// TODO Auto-generated constructor stub
	}

	public Bible(int id, String testament, String book, String chapter, String verse, String vtext) {
		this.id = id;
		this.testament = testament;
		this.book = book;
		this.chapter = chapter;
		this.verse = verse;
		this.vtext = vtext;
	}
	
	public Bible(String book, String chapter, String verse) {
		this.book = book;
		this.chapter = chapter;
		this.verse = verse;
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTestament() {
		return testament;
	}

	public void setTestament(String testament) {
		this.testament = testament;
	}

	public String getBook() {
		return book;
	}

	public void setBook(String book) {
		this.book = book;
	}

	public String getChapter() {
		return chapter;
	}

	public void setChapter(String chapter) {
		this.chapter = chapter;
	}

	public String getVerse() {
		return verse;
	}

	public void setVerse(String verse) {
		this.verse = verse;
	}

	public String getVtext() {
		return vtext;
	}

	public void setVtext(String vtext) {
		this.vtext = vtext;
	}
	
	
}

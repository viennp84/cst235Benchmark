package data;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import beans.Order;

/**
 * OrderDataService.cs Author: Vien Nguyen OrderDataService implementations from
 * the DataAccessInterface.
 */

@Stateless
@Local(DataAccessInterface.class)
@LocalBean
public class OrderDataService implements DataAccessInterface<Order> {
	// Connection to database
	java.sql.Connection conn = null;
	String url = "jdbc:postgresql://localhost:5432/postgres";
	String username = "postgres";
	String password = "Chihaiis02";

	// get the list of orders
	@Override
	public List<Order> findAll() {
		List<Order> orders = new ArrayList<Order>();

		String sql = "Select * FROM testapp.ORDERS";
		try {
			// Connect to the Database
			conn = DriverManager.getConnection(url, username, password);

			// Execute SQL Query and loop over result set.
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				orders.add(new Order(rs.getString("ORDER_NO"), rs.getString("PRODUCT_NAME"), rs.getFloat("PRICE"),
						rs.getInt("QUANTITY")));
			}
			conn.close();
		}

		catch (SQLException e) {
			System.out.println("Connection failure.");
			e.printStackTrace();
		}
		return orders;
	}

	// Add a new order into the database
	@Override
	public boolean create(Order order) {

		boolean isUserCreated = false;
		String sql1 = "insert into testapp.ORDERS(order_no, product_name, price, quantity)" + "values (?, ?, ?, ?)";
		try {
			conn = DriverManager.getConnection(url, username, password);
			PreparedStatement st = conn.prepareStatement(sql1);
			st.setString(1, order.getOrderNo());
			st.setString(2, order.getProductName());
			st.setFloat(3, order.getPrice());
			st.setInt(4, order.getQuantity());
			st.executeUpdate();
			conn.close();
			isUserCreated = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isUserCreated;
	}

	// Update an available order
	@Override
	public boolean update(Order order) {
		boolean isUpdated = false;
		String sql = "UPDATE testapp.ORDERS set product_name = ?, price = ?, quantity = ?  WHERE order_no =?";
		try {
			// Connect to the Database
			conn = DriverManager.getConnection(url, username, password);
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, order.getProductName());
			st.setFloat(2, order.getPrice());
			st.setInt(3, order.getQuantity());
			st.setString(4, order.getOrderNo());
			st.executeUpdate();
			conn.close();
			isUpdated = true;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isUpdated;
	}

	// Delete an order out of database.
	@Override
	public boolean delete(Order order) {
		boolean isDeleted = false;
		String sql = "DELETE FROM testapp.ORDERS WHERE order_no =?";
		try {
			// Connect to the Database
			conn = DriverManager.getConnection(url, username, password);
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, order.getOrderNo());
			st.executeUpdate();
			conn.close();
			isDeleted = true;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isDeleted;
	}

}

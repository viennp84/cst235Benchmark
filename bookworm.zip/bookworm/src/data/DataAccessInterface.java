package data;

import java.util.List;
/**
 * DataAccessInterface.cs
 * Author: Vien Nguyen
 * DataAccessInterface defines the interface used to call the its implementations.
 */
public interface DataAccessInterface <T> {
	
	//CRUD methods
	public List<T> findAll();

	public boolean create(T t);

	public boolean update(T t);

	public boolean delete(T t);
}

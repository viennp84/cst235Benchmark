package data;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import beans.Bible;
import javax.enterprise.inject.Alternative;
import javax.ws.rs.core.Response;

/**
 * BibleDataAccessService.cs Author: Vien Nguyen BibleDataAccessService implementations from
 * the DataAccessInterface.
 */

@Alternative
@Stateless
@Local(DataAccessInterface.class)
@LocalBean
public class BibleDataService implements DataAccessInterface<Bible>{

	// Connection to database
	java.sql.Connection conn = null;
	String url = "jdbc:postgresql://localhost:5432/postgres";
	String username = "postgres";
	String password = "Chihaiis02";
	@Override
	public List<Bible> findAll() {
		List<Bible> bibles = new ArrayList<Bible>();

		String sql = "Select * FROM public.kjv";
		try {
			// Connect to the Database
			conn = DriverManager.getConnection(url, username, password);

			// Execute SQL Query and loop over result set.
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				bibles.add(new Bible(rs.getInt("id"), rs.getString("testament"), rs.getString("book"), rs.getString("chapter"), rs.getString("verse"), rs.getString("vtext")));
			}
			conn.close();
		}

		catch (SQLException e) {
			System.out.println("Connection failure.");
			e.printStackTrace();
		}
		return bibles;
	}
	@Override
	public boolean create(Bible t) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean update(Bible t) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean delete(Bible t) {
		// TODO Auto-generated method stub
		return false;
	}
//	Given a word, the service will return the exact first occurrence of the word (if it exists). The result will include the book name, chapter number, and verse number
	public List<Bible> findVerse(Bible bible) {
		List<Bible> bibles = new ArrayList<Bible>();
		String sql = "Select book, chapter, verse FROM public.kjv where vtext like ? ";
		try {
			// Connect to the Database
			conn = DriverManager.getConnection(url, username, password);

			// Execute SQL Query and loop over result set.
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1,"%" + bible.getVtext()+ "%");
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				bibles.add(new Bible(rs.getString("book"), rs.getString("chapter"), rs.getString("verse")));
			}
			conn.close();
		}

		catch (SQLException e) {
			System.out.println("Connection failure.");
			e.printStackTrace();
		}
		return bibles;
	}
	
	//Count number of occurrence of the world
	public Response getWordCount(Bible bible) {
		int count = 0;
		String sql = "Select vtext FROM public.kjv where vtext like ? ";
		try {
			// Connect to the Database
			conn = DriverManager.getConnection(url, username, password);

			// Execute SQL Query and loop over result set.
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1,"%" + bible.getVtext()+ "%");
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				count++;
			}
			conn.close();
		}

		catch (SQLException e) {
			System.out.println("Connection failure.");
			e.printStackTrace();
		}
		return Response.status(Response.Status.OK).entity("The word occurences is :" + count).build();
	}
	
}

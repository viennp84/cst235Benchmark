package business;
/**
 * MyTimerService.cs
 * Author: Vien Nguyen
 * My Timer Service, set timer, write log
 */
import java.util.logging.Logger;

import javax.annotation.Resource;
import javax.ejb.Schedule;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;

/**
 * MyTimerService.cs
 * Author: Vien Nguyen
 * Session Bean implementation class MyTimerService
 */

@Stateless
public class MyTimerService {

	//Declare the timer servic.
	@Resource
	TimerService timerService;
	
	private static final Logger logger = Logger.getLogger("business.MyTimerService");
    public MyTimerService() {
        // TODO Auto-generated constructor stub
    }
	//The method to write the log with a timer schedule.
	@SuppressWarnings("unused")
	@Schedule(second="*/10", minute="*", hour="0-23", dayOfWeek="Mon-Fri",
      dayOfMonth="*", month="*", year="*", info="MyTimer")
    private void scheduledTimeout(final Timer t) {
       logger.info("@Schedule called at: " + new java.util.Date());
    }

	public TimerService getTimerService() {
		return timerService;
	}

	public void setTimer(long  interval) {
		timerService.createTimer(interval, "My Timer");
	}
	@Timeout 
	public void programmicTimer(Timer timer)
	{
		logger.info("Time is expired.");
	}
	
}